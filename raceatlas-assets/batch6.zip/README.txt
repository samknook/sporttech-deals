RaceAtlas batch 6: 10 unique AI illustrative images; not official event photography.
